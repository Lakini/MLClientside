# NeuralNetworkVisualBuilder
This is the visual builder for deep neural network which is going to use in WSO2 Machine Learner.This is GSOC-16 project.
